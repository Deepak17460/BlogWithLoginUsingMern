import React from 'react'
import {AppBar, Toolbar, Typography, Button, Box, Tab, Tabs} from '@mui/material';
import { useDispatch, useSelector } from "react-redux";
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { authActions } from '../../store/storage';

const Header = () => {
  const isLoggedIn = useSelector(state=>state.isLoggedIn);
  const dispatch = useDispatch();

  const [value,setValue] =useState();
  return (
    <AppBar  position="sticky" sx={{  background: 'tomato'}}>
     
         <Toolbar>
            <Typography variant="h6" component="div">
                Blog
            </Typography>
            { isLoggedIn &&
            <Box display="flex" marginLeft="auto" marginRight="auto">
              <Tabs textColor="inherit" value={value} onChange={(e,val)=>setValue(val)}>
              <Tab LinkComponent={Link} to='/blogs' label="All Blogs" ></Tab>
                <Tab LinkComponent={Link} to='/myBlogs'label="My Blogs"  ></Tab>
                <Tab LinkComponent={Link} to='/blogs/add' label="Add Blog"  ></Tab>
               
              </Tabs>
            </Box>
            }
           
            <Box display="flex" marginLeft="auto">
               { !isLoggedIn && <><Button LinkComponent={Link} to='/auth' variant="contained" sx={{borderRadius:10, backgroundColor:'blue', margin:1}}>Login</Button>
                <Button LinkComponent={Link} to='/auth' variant="contained" sx={{borderRadius:10, backgroundColor:'blue', margin:1}}>SignUp</Button>
                </>}
                {isLoggedIn && <Button onClick={() => dispatch(authActions.logout())} LinkComponent={Link} to='/auth' variant="contained" sx={{borderRadius:10, backgroundColor:'blue', margin:1}}>Logout</Button>}
            </Box>
         
        </Toolbar>
    </AppBar>
  )
}

export default Header
