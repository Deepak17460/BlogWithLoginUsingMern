import React from 'react';
import { Box, Button, TextField, Typography } from "@mui/material";
import { useState } from 'react';
import axios from "axios";
import {useDispatch} from 'react-redux';
import { authActions } from '../../store/storage';
import { useNavigate } from 'react-router-dom';
const Auth = () => {
  const [isSignup, setIsSignup] = useState(false);
  const dispatch=useDispatch();
  const navigate =useNavigate();
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
   
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };

  const sendRequest = async (type="login") => {
    const res = await axios
    .post(`http://localhost:8000/${type}`, {
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      })
      .catch((err) => console.log(err));

    const data = await res.data;
    console.log(data);
    return data;
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
   
    if(isSignup){
       await sendRequest("signUp")
       .then((data) => {localStorage.setItem("userId", data.newUser._id); console.log(data);
       setIsSignup(false);
      }).catch((error)=>{
        console.log(error);
      })
     
    }
    else{
     await sendRequest()
     .then((data) => localStorage.setItem("userId", data.user._id))
      .then(() => dispatch(authActions.login()))
      .then(() => navigate('/blogs'))
      .then((data)=>{console.log(data)})
      .catch((error)=>{console.log(error)});
    }
   
  };


  return (
    <div >
        <form onSubmit={handleSubmit}>
        <Box 
          maxWidth={400}  display="flex" flexDirection={"column"} alignItems="center" justifyContent={"center"} boxShadow="10px 10px 20px #ccc"
          padding={3}
          margin="auto"
          marginTop={5}
          borderRadius={5}>
            <Typography variant="h3" padding={3} textAlign="center">{isSignup ? "SignUp": "Login"}</Typography>
                { isSignup &&  <TextField name="name" value={inputs.name}  placeholder="Name" margin="normal" onChange={handleChange}/>}   
              <TextField name="email" value={inputs.email} type={"email"}  placeholder="Email" margin="normal" onChange={handleChange}/>
              <TextField name="password" value={inputs.password} type={"password"} placeholder="Password" margin="normal" onChange={handleChange}/>
              <Button  variant="contained"
                sx={{ borderRadius: 3, marginTop: 3 }}
                color="warning" type="submit">Submit</Button>
              <Button onClick={()=>setIsSignup(!isSignup)}  sx={{ borderRadius: 3, marginTop: 3 }}>
                {isSignup ? "Have an account?" : "Don't Have an Account? "}
              </Button>
        </Box>
      </form>
      
    </div>
  )
}

export default Auth