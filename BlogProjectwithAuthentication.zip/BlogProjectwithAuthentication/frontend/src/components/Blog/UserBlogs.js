import React from 'react';
import axios from 'axios';
import { useEffect,useState } from 'react';
import Blog from './Blog';



let userName;

const UserBlogs = () => {

  const id=localStorage.getItem("userId");
  const [userBlog,setUserBlog]=useState([]);

  const sendRequest=async()=>{
      const response= await axios.get(`http://localhost:8000/allUser/blogs/${id}`).catch((error)=>console.log(error));
      const data=await response.data;
     return data;
  }
  
  useEffect(()=>{
    
    sendRequest().then((data)=>{
      setUserBlog(data.blogs);
      userName=data.name;
    });
  },[])
 console.log("hi",userBlog.user);
 return(
  <div>
    {
      userBlog && userBlog.map((blog,index)=>(
        <Blog
        isUser={true}
        userName={userName}
        id={blog._id}
        title={blog.title}
        description={blog.description}
        imageURL={blog.image}
        createdDate={new Date(blog.createdDate).toDateString()}
      />
      ))
    }
  </div>
 )
}

export default UserBlogs