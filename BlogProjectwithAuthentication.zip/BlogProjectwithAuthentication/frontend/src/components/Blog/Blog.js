import React from 'react'
import { Avatar, Box, Card, CardContent, CardHeader, CardMedia, IconButton, Typography,} from "@mui/material";
import ModeEditOutlineIcon from "@mui/icons-material/ModeEditOutline";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import { Link,useNavigate } from 'react-router-dom';
import axios from "axios";
import styled from '@emotion/styled';

const CardHeader1=styled(CardHeader)`
font-weight:1200;
color:red;
`;
const Blog = ({title,description,imageURL,userName,createdDate, isUser,id}) => {
  const navigate=useNavigate();
  const handleEdit=()=>{
    navigate(`/myBlogs/${id}`);
  }
  const deleteRequest = async () => {
    try{
    const res = await axios
      .delete(`http://localhost:8000/blog/delete/${id}`)
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
    }
    catch(error){
      console.log(error);
    }
  };

  const handleDelete = async () => {
    deleteRequest()
    .then(() => {
      navigate("/");
      setTimeout(() => navigate("/blogs"), 1);
     
    });
  };
  
  return (
    <Card sx={{ width: "40%", margin: "auto", mt: 2, padding: 2, boxShadow: "5px 5px 10px #ccc",":hover": {
      boxShadow: "10px 10px 20px #ccc",
    },}}>
      {isUser && (
          <Box display="flex">
            <IconButton onClick={handleEdit} sx={{ marginLeft: "auto" }}>
              <ModeEditOutlineIcon />
            </IconButton>
            <IconButton onClick={handleDelete}>
              <DeleteForeverIcon color="error" />
            </IconButton>
          </Box>
        )}
    <CardHeader1
      avatar={
        <Avatar sx={{ bgcolor: "black" }} aria-label="recipe">
          {userName ? userName.charAt(0) : ""}
        </Avatar>
      }
    
      title={title}
      subheader={new Date().toDateString()}
    />
    <CardMedia
      component="img"
      height="194"
      image={imageURL}
      alt="Paella dish"
    />
    <CardContent>
      <Typography variant="body2" color="text.secondary">
      <b>{userName}</b> {": "} {description}
      </Typography>
    </CardContent>
  </Card>
  )
}

export default Blog