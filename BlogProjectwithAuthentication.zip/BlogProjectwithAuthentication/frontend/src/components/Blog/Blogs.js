import axios from 'axios'
import React, { useEffect, useState } from 'react'
import Blog from './Blog';
import { Box,Link } from '@mui/material';
const Blogs = () => {

  const [blogs, setBlogs] = useState([]);
  useEffect(( )=>{
    const sendRequest = async()=>{
      const response= await axios.get(`http://localhost:8000/blogs`).catch((error)=>console.log(error));
       if(response.status===200){
        setBlogs(response.data);
       }
    }
    sendRequest();
  }, []);
  // console.log(blogs);
  blogs.map((blog)=>{
    console.log(localStorage.getItem("userId"),blog.user._id);
  })
  
   return (
    <div>
      {
        blogs &&
        blogs.map((blog, index) => (
          <Blog
          isUser={localStorage.getItem("userId") === blog.user._id}
            id={blog._id}
            title={blog.title}
            description={blog.description}
            imageURL={blog.image}
            userName={blog.user.name}
            createdDate={new Date(blog.createdDate).toDateString()}
          />
        ))
      }
    </div>
  );
  
};

export default Blogs