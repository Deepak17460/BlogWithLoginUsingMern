import React from 'react'
import { Box,Typography } from '@mui/material';

const Home = () => {
  return (
    <Box
    style={{backgroundColor:"#ffa8B6"}}
    border={3}
    borderColor="linear-gradient(90deg, rgba(58,75,180,1) 2%, rgba(116,49,110,1) 36%, rgba(2,0,161,1) 73%, rgba(69,92,252,1) 100%)"
    borderRadius={10}
    boxShadow="10px 10px 20px #ccc"
    padding={3}
    margin={"auto"}
    marginTop={3}
    display="flex"
    flexDirection={"column"}
    width={"80%"}
    >
       <Typography style={{backgroundColor:"#ffa8B6"}}
              fontWeight={"bold"}
              padding={3}
              color="white"
              variant="h2"
              textAlign={"center"}
            >
              <p>Welcome to the Blog World!</p>
            </Typography>
    </Box>
  )
}

export default Home;