import Header from "./components/Header/Header.js";
import { Route, Routes } from "react-router-dom";
import AddBlog from "./components/Blog/AddBlog.js";
import UserBlogs from "./components/Blog/UserBlogs.js";
import BlogDetail from "./components/Blog/BlogDetail.js";
import Blogs from "./components/Blog/Blogs.js";
import Auth from "./components/Auth/Auth.js";
import React from "react";
import { useSelector } from "react-redux";
import Home from "./components/Home/Home.js";
function App() {
  const isLoggedIn = useSelector(state=>state.isLoggedIn);
  console.log(isLoggedIn);
  return (
    <React.Fragment>
  
    <header>
      <Header />
    </header>
    <main>
      <Routes>
     
          <Route path="/auth" element={<Auth />} />
          <Route path="/" element={<Home/>} />
            <Route path="/blogs" element={<Blogs />} />
            <Route path="/blogs/add" element={<AddBlog />} />
            <Route path="/myBlogs" element={<UserBlogs />} />
            <Route path="/myBlogs/:id" element={<BlogDetail />} />
         
        
      </Routes>
    </main>
   
   </React.Fragment>
  );
}

export default App;
